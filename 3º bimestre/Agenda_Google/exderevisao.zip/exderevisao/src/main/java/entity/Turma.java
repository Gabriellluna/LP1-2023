package entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;
@Entity
@Table
public class Turma {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;
    @Column
    @ManyToOne
    private Professor professor;
    @Column
    private String horario;
    @Column
    @ManyToMany
    private List<Aluno> alunos;
    @Column
    private String codigo;

    public Turma( String horario, String codigo) {

        this.horario = horario;
        this.alunos = new ArrayList<>();
        this.codigo = codigo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public List<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(List<Aluno> alunos) {
        this.alunos = alunos;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return "Turma{" +
                "id=" + id +
                ", professor=" + professor +
                ", horario='" + horario + '\'' +
                ", alunos=" + alunos +
                ", codigo='" + codigo + '\'' +
                '}';
    }
}
