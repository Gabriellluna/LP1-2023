package entity;

import jakarta.persistence.*;

@Entity
@Table
public class Nota {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;
    @Column
    @OneToMany(cascade = CascadeType.ALL)
    private Turma turma;
    @Column
    private Double nota;
    public Nota(){}

    public Nota( Double nota) {

        this.nota = nota;

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Turma getTurma() {
        return turma;
    }

    public void setTurma(Turma turma) {
        this.turma = turma;
    }

    public Double getNota() {
        return nota;
    }

    public void setNota(Double nota) {
        this.nota = nota;
    }

    @Override
    public String toString() {
        return "Nota{" +
                "id=" + id +
                ", turma=" + turma +
                ", nota=" + nota +
                '}';
    }
}
