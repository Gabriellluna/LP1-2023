package entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;
@Entity
@Table
public class Aluno {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;
    @Column
    private String senha;
    @Column
    @ManyToOne(cascade = CascadeType.ALL)
    private List<Nota> notas;
    @Column
    private String nome;
    @Column
    private String prontuario;
    @Column
    private Double media;

    public Aluno(String senha,String nome, String prontuario) {
        this.senha = senha;
        this.notas = new ArrayList<>();
        this.nome = nome;
        this.prontuario = prontuario;

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public List<Nota> getNotas() {
        return notas;
    }

    public void setNotas(List<Nota> notas) {
        this.notas = notas;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProntuario() {
        return prontuario;
    }

    public void setProntuario(String prontuario) {
        this.prontuario = prontuario;
    }

    public Double getMedia() {
        media = 0.0;

        for(Nota nota : notas){
            media = media + nota.getNota();
        }

        return media/ notas.size();
    }

    public void setMedia() {
        media = 0.0;

        for (Nota nota : notas) {
            media = media + nota.getNota();

        }
       media = media/notas.size();
    }

    @Override
    public String toString() {
        return "Aluno{" +
                "id=" + id +
                ", senha='" + senha + '\'' +
                ", notas=" + notas +
                ", nome='" + nome + '\'' +
                ", prontuario='" + prontuario + '\'' +
                ", media=" + media +
                '}';
    }
}
