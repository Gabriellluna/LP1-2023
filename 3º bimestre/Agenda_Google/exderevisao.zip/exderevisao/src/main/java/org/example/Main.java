package org.example;

import entity.Aluno;
import entity.Nota;
import entity.Professor;
import entity.Turma;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        Professor prof1 = new Professor("12345", "54682325884", "Igor de Moraes Sampaio", "SP3090329");


        Aluno aluno1 = new Aluno("123", "Gabriel Luna Maia", "SP3090329");

        Nota nota1 = new Nota(10.0);
        Nota nota2 = new Nota(5.0);
        Nota nota3 = new Nota(10.0);

        Turma turma1 = new Turma("07:00", "1245679");
        turma1.setProfessor(prof1);
        aluno1.setNotas(List.of(nota1, nota2, nota3));
        //nota1.setTurma(turma1);Professor, eu comentei essa linha porque não estava rodando e iria comprometer o resto do código
        //nota2.setTurma(turma1);Professor, eu comentei essa linha porque não estava rodando e iria comprometer o resto do código
        //nota3.setTurma(turma1);Professor, eu comentei essa linha porque não estava rodando e iria comprometer o resto do código

        turma1.setAlunos(List.of(aluno1));

        aluno1.setMedia();
        System.out.println(turma1);
        System.out.println(aluno1.getMedia());


    }

    //vamos usar o hibernateutil agr
    Session session  = HibernateUtil.getSessionFactory().openSession();
    //estava dando erro porque precisamos da sessão do hibernate, não do h2
    //Ali nas importações tinha org.h2.engine.Session
    //Mudei para or.hibernate.Session

    //Depois de abrir a sessão, iniciamos a transição para o banco de dados
    Transaction transaction = session.beginTransaction();

    session.persist(turma1);

    transaction.commit();
    //fim da transação

    //buscando as turmas e guardando dentro dessa lista
    List<Turma> TURMA = session.createQuery("from Turma", Turma.class).list();
    for (Turma t : TURMA){
        System.out.println(t);
    }

}