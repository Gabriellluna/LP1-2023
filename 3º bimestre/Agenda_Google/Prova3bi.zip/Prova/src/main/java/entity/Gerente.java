package entity;


import jakarta.persistence.*;

@Table
@Entity
public class Gerente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private String responsabilidade;
    @Column
    private Double salario;
    @Column
    private String nome;

    public Gerente(){
    }

    public Gerente(String responsabilidade, Double salario, String nome) {
        this.responsabilidade = responsabilidade;
        this.salario = salario;
        this.nome = nome;
    }

    public String getResponsabilidade() {
        return responsabilidade;
    }

    public void setResponsabilidade(String responsabilidade) {
        this.responsabilidade = responsabilidade;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Gerente{" +
                "id=" + id +
                ", responsabilidade='" + responsabilidade + '\'' +
                ", salario=" + salario +
                ", nome='" + nome + '\'' +
                '}';
    }
}
