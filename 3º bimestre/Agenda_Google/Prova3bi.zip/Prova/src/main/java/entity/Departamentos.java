package entity;

import jakarta.persistence.*;

import java.util.List;


@Table
@Entity
public class Departamentos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "funcionario_id")
    private List<Funcionarios> funcionarios;
    @Column
    private String nome;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "gerente_id")
    private Gerente gerente;

    public Departamentos(String nome) {
        this.nome = nome;
    }

    public List<Funcionarios> getFuncionarios() {
        return funcionarios;
    }

    public void setFuncionarios(List<Funcionarios> funcionarios) {
        this.funcionarios = funcionarios;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Gerente getGerente() {
        return gerente;
    }

    public void setGerente(Gerente gerente) {
        this.gerente = gerente;
    }

    @Override
    public String toString() {
        return "Departamentos{" +
                "id=" + id +
                ", funcionarios=" + funcionarios +
                ", nome='" + nome + '\'' +
                ", gerente=" + gerente +
                '}';
    }
}
