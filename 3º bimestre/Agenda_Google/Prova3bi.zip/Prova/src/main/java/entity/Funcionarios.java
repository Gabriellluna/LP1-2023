package entity;


import jakarta.persistence.*;

import java.util.Scanner;


@Table
@Entity
public class Funcionarios {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private String cpf;
    @Column
    private String nome;
    @Column
    private Double salario;


    public Funcionarios(String cpf, String nome) {
        this.cpf = cpf;
        this.nome = nome;

    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        return "Funcionarios{" +
                "id=" + id +
                ", cpf='" + cpf + '\'' +
                ", nome='" + nome + '\'' +
                ", salario=" + salario +
                '}';
    }

    public Gerente verificasalario(Gerente gerente) {

        Scanner scanner = new Scanner(System.in);
        if (this.salario <= gerente.getSalario()) {
            System.out.println("Salário alterado com sucesso");
        } else {
            while(this.salario > gerente.getSalario()) {
                System.out.println("Você não pode ter um funcionário com salário maior que o do gerente");
                System.out.println("Insira um novo salaŕio menor que: " + gerente.getSalario());
                setSalario(scanner.nextDouble());
            }
            }
        return gerente;
    }


    }

