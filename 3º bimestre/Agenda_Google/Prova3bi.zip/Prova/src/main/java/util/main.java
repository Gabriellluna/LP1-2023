package util;

import entity.Departamentos;
import entity.Empresa;
import entity.Funcionarios;
import entity.Gerente;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class main {
    public static void main(String[] args) {

        Empresa empresa1 = new Empresa("Loogle");
        Departamentos departamento1 = new Departamentos("Recursos Humanos");
        Gerente gerente1 = new Gerente("Gerenciar o RH", 10500.00, "Gabriel Luna Maia");
        Funcionarios funcionario1 = new Funcionarios("12345678920", "Gustavo Luna Maia");
        Funcionarios funcionario2 = new Funcionarios("45698732128", "Jonathan Calleri");
        Funcionarios funcionario3 = new Funcionarios("65478932114", "Luciano Neves");
        funcionario1.setSalario(100.00);
        funcionario2.setSalario(200.00);
        funcionario3.setSalario(50000.00);
        funcionario1.verificasalario(gerente1);
        funcionario2.verificasalario(gerente1);
        funcionario3.verificasalario(gerente1);

        departamento1.setFuncionarios(List.of(funcionario1, funcionario2, funcionario3));
        departamento1.setGerente(gerente1);
        empresa1.setDepartamentos(List.of(departamento1));

        //System.out.println(empresa1);

        Session session  = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        session.persist(empresa1);

        transaction.commit();

        List<Empresa> empresas = session.createQuery("from Empresa", Empresa.class).list();
        for(Empresa empresa : empresas){
            System.out.println(empresa);
        }
    }
}
